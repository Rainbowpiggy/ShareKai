import React from "react";
import { createRoot } from "react-dom/client";
import ShareKAI from "./App.jsx";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ShareKAI />
  </React.StrictMode>,
);
